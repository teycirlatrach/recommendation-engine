const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

// Chemin vers le fichier proto
const PROTO_PATH = './user_profile.proto';

// Options de chargement
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
});

// Charger le service
const userProfileProto = grpc.loadPackageDefinition(packageDefinition).userProfile;

// Données simulées
const users = {
    "user1": {
        user_id: "user1",
        preferences: ["films", "musique"],
        viewed_items: ["prod1", "prod2"]
    },
    "user3": {
        user_id: "User3",
        preferences: ["sport", "lecture"],
        viewed_items: ["prod3"]
    }
};

// Implémentation du service
const service = {
    GetUserProfile: (call, callback) => {
        const user = users[call.request.user_id];
        if (user) {
            callback(null, user);
        } else {
            callback({
                code: grpc.status.NOT_FOUND,
                details: "Utilisateur non trouvé"
            });
        }
    },
    UpdatePreferences: (call, callback) => {
        const user = users[call.request.user_id];
        if (user) {
            user.preferences = call.request.preferences;
            callback(null, user);
        } else {
            callback({
                code: grpc.status.NOT_FOUND,
                details: "Utilisateur non trouvé"
            });
        }
    }
};

// Créer le serveur
const server = new grpc.Server();
server.addService(userProfileProto.UserProfileService.service, service);
server.bindAsync('0.0.0.0:50051', grpc.ServerCredentials.createInsecure(), () => {
    server.start();
    console.log('Microservice Profil Utilisateur démarré sur le port 50051');
});