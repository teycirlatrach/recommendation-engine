const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

const PROTO_PATH = './product_catalog.proto';

const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
});

const productProto = grpc.loadPackageDefinition(packageDefinition).productCatalog;

// Données simulées
const products = [
    {
        product_id: "prod1",
        name: "Smartphone X",
        category: "électronique",
        tags: ["nouveau", "promo"]
    },
    {
        product_id: "prod2",
        name: "Livre sur les Microservices",
        category: "livres",
        tags: ["technologie", "programmation"]
    },
    {
        product_id: "prod3",
        name: "Casque Audio",
        category: "électronique",
        tags: ["audio", "accessoire"]
    }
];

const service = {
    GetProduct: (call, callback) => {
        const product = products.find(p => p.product_id === call.request.product_id);
        if (product) {
            callback(null, product);
        } else {
            callback({
                code: grpc.status.NOT_FOUND,
                details: "Produit non trouvé"
            });
        }
    },
    SearchProducts: (call) => {
        const query = call.request.query.toLowerCase();
        products.forEach(product => {
            if (product.name.toLowerCase().includes(query) || 
                product.category.toLowerCase().includes(query) ||
                product.tags.some(tag => tag.toLowerCase().includes(query))) {
                call.write(product);
            }
        });
        call.end();
    }
};

const server = new grpc.Server();
server.addService(productProto.ProductCatalogService.service, service);
server.bindAsync('0.0.0.0:50052', grpc.ServerCredentials.createInsecure(), () => {
    server.start();
    console.log('Microservice Catalogue Produits démarré sur le port 50052');
});