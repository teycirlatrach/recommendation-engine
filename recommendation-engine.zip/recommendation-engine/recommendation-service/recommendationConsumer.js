const { Kafka } = require('kafkajs');
const { RecommendationEngine } = require('./recommendationEngine'); // Hypothetical module

class RecommendationConsumer {
    constructor() {
        this.kafka = new Kafka({
            clientId: 'recommendation-service',
            brokers: ['localhost:9092'],
            retry: {
                initialRetryTime: 100,
                retries: 8
            }
        });
        
        this.consumer = this.kafka.consumer({ 
            groupId: 'recommendation-group',
            sessionTimeout: 30000,
            heartbeatInterval: 10000
        });
        
        this.connected = false;
    }

    async connect() {
        try {
            await this.consumer.connect();
            await this.consumer.subscribe({ 
                topic: 'user_interactions', 
                fromBeginning: false // Usually we want only new messages
            });
            this.connected = true;
            console.log('✅ Consumer connecté et abonné à user_interactions');
        } catch (error) {
            console.error('❌ Erreur de connexion au consumer Kafka:', error);
            this.connected = false;
            throw error;
        }
    }

    async start() {
        if (!this.connected) {
            await this.connect();
        }

        await this.consumer.run({
            eachMessage: async ({ topic, partition, message }) => {
                try {
                    const interaction = this.parseMessage(message);
                    console.log(`📩 Nouvelle interaction (partition ${partition}):`, interaction);
                    
                    // Process recommendation
                    const recommendations = await this.generateRecommendations(interaction);
                    console.log(`✨ Recommandations pour ${interaction.userId}:`, recommendations);
                    
                    // Here you would typically:
                    // 1. Store recommendations in DB
                    // 2. Send to another Kafka topic
                    // 3. Push to user via WebSocket
                } catch (error) {
                    console.error('⚠️ Erreur de traitement du message:', error);
                    // Implement retry or dead-letter queue logic here
                }
            },
        });
    }

    parseMessage(message) {
        try {
            return JSON.parse(message.value.toString());
        } catch (error) {
            console.error('❌ Message JSON invalide:', message.value.toString());
            throw new Error('Invalid message format');
        }
    }

    async generateRecommendations(interaction) {
        // In a real implementation, this would:
        // 1. Check user preferences
        // 2. Analyze interaction patterns
        // 3. Query product catalog
        // 4. Apply recommendation algorithms
        
        // Mock implementation
        return {
            userId: interaction.userId,
            recommendations: ["prod3", "prod4"],
            timestamp: new Date().toISOString()
        };
    }

    async disconnect() {
        try {
            await this.consumer.disconnect();
            console.log('🛑 Consumer déconnecté proprement');
        } catch (error) {
            console.error('Erreur lors de la déconnexion:', error);
        }
    }
}

// Gestion des arrêts
process.on('SIGTERM', async () => {
    await consumer.disconnect();
    process.exit(0);
});

process.on('SIGINT', async () => {
    await consumer.disconnect();
    process.exit(0);
});

// Lancement du service
(async () => {
    const consumer = new RecommendationConsumer();
    try {
        await consumer.start();
    } catch (error) {
        console.error('Échec du démarrage du consumer:', error);
        process.exit(1);
    }
})();