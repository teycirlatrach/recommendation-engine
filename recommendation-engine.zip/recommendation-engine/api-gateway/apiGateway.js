const express = require('express');
const { ApolloServer } = require('@apollo/server');
const { expressMiddleware } = require('@apollo/server/express4');
const { json } = require('body-parser');
const cors = require('cors');
const { Kafka } = require('kafkajs');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// Import schéma + résolveurs
const { typeDefs, resolvers } = require('./schema');

// Charger le proto user-profile
const PROTO_PATH = path.join(__dirname, '../user-profile-service/user_profile.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
});
const userProfileProto = grpc.loadPackageDefinition(packageDefinition).userProfile;

// Kafka setup
const kafka = new Kafka({
    clientId: 'api-gateway',
    brokers: ['localhost:9092']
});
const producer = kafka.producer();

// Express setup
const app = express();
const port = 3000;

app.use(json());
app.use(cors());

// Apollo Server
const server = new ApolloServer({ typeDefs, resolvers });

(async () => {
    await server.start();
    app.use('/graphql', expressMiddleware(server));

    // Route REST fallback vers gRPC
    app.get('/user/:userId', async (req, res) => {
        try {
            const client = new userProfileProto.UserProfileService(
                'localhost:50051',
                grpc.credentials.createInsecure()
            );

            client.GetUserProfile({ user_id: req.params.userId }, (err, response) => {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.json(response);
                }
            });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    });

    // Démarrer Express
    app.listen(port, () => {
        console.log(`API Gateway démarré sur http://localhost:${port}`);
    });

    await producer.connect();
    console.log('Producteur Kafka connecté');
})();
