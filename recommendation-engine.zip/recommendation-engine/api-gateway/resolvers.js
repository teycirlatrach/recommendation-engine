const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

function loadProto(path) {
    const packageDefinition = protoLoader.loadSync(path, {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true
    });
    return grpc.loadPackageDefinition(packageDefinition);
}

// Charger les services gRPC localement (pas à exporter)
const userProfilePackage = loadProto('./../user-profile-service/user_profile.proto');
const productPackage = loadProto('./../product-catalog-service/product_catalog.proto');

// Clients gRPC
const userProfileClient = new userProfilePackage.userProfile.UserProfileService(
    'localhost:50051',
    grpc.credentials.createInsecure()
);

const productClient = new productPackage.productCatalog.ProductCatalogService(
    'localhost:50052',
    grpc.credentials.createInsecure()
);

// Définir les résolveurs GraphQL
const resolvers = {
    Query: {
        getUserProfile: (_, { userId }) => {
            return new Promise((resolve, reject) => {
                userProfileClient.GetUserProfile({ user_id: userId }, (err, response) => {
                    if (err) reject(err);
                    else resolve({
                        userId: response.user_id,
                        preferences: response.preferences,
                        viewedItems: response.viewed_items
                    });
                });
            });
        },
        getProduct: (_, { productId }) => {
            return new Promise((resolve, reject) => {
                productClient.GetProduct({ product_id: productId }, (err, response) => {
                    if (err) reject(err);
                    else resolve(response);
                });
            });
        },
        searchProducts: (_, { query }) => {
            return new Promise((resolve, reject) => {
                const products = [];
                const call = productClient.SearchProducts({ query });
                call.on('data', (product) => products.push(product));
                call.on('end', () => resolve(products));
                call.on('error', (err) => reject(err));
            });
        }
    },
    Mutation: {
        updatePreferences: (_, { userId, preferences }) => {
            return new Promise((resolve, reject) => {
                userProfileClient.UpdatePreferences({ user_id: userId, preferences }, (err, response) => {
                    if (err) reject(err);
                    else resolve({
                        userId: response.user_id,
                        preferences: response.preferences,
                        viewedItems: response.viewed_items
                    });
                });
            });
        }
    }
};

module.exports = resolvers;
