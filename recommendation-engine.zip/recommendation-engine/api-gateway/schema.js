const { gql } = require('graphql-tag');
const resolvers = require('./resolvers'); // <- tu n'utilises pas la destructuration ici !

const typeDefs = gql`
    type UserProfile {
        userId: String!
        preferences: [String!]!
        viewedItems: [String!]!
    }

    type Product {
        productId: String!
        name: String!
        category: String!
        tags: [String!]!
    }

    type Query {
        getUserProfile(userId: String!): UserProfile
        getProduct(productId: String!): Product
        searchProducts(query: String!): [Product!]
    }

    type Mutation {
        updatePreferences(userId: String!, preferences: [String!]!): UserProfile
    }
`;

module.exports = { typeDefs, resolvers };
